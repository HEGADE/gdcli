CLI_OPTIONS = ("-q", "-s", "-f", "-e", "-op","-b","-l")

DISPLAY_OPTIONS = (
    "option",
    "search_query",
    "site",
    "file_type",
    "exclude",
    "bio",
    "location"

)
