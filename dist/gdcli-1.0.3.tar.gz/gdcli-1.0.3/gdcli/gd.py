
from gdcli.commands.cli import Cli


cli=Cli()
def start():
    cli()

start()